# mypublicip
Python package to get the public IP address

**Exemple:**
```
import mypublicip

ip = mypublicip.ip()

print(ip)
```